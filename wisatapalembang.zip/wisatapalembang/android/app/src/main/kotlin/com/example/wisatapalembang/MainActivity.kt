package com.example.wisatapalembang

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
